//stack_arr.c
// Created by Alamin Momin on 2/21/20.
//The purpose of this file is to write the declarations of all the functions found in stack_arr.h

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "stack_arr.h"

void makeStack(Stack312 *s) {
    s->top = -1;
}

bool isFull(Stack312 s) {
    return (s.top == MAX_ELEMENTS - 1);
}

bool isEmpty(Stack312 s) {
    return (s.top == -1);
}

void push(StackEntry e, Stack312 *s) {
    s->top = s->top + 1;
    s->elements[s->top] = e;
}

StackEntry pop(Stack312 *s) {
    char info;
    info = s->elements[s->top];
    s->top = s->top - 1;
    return info;
}

void checker(char *buffer, int length, Stack312 *s) {
    char *temp_grid[0];
    temp_grid[0] = malloc((length * sizeof(char)));         //create an array with the length of the line
    strcpy(temp_grid[0], buffer);                                //copy the contents of the buffer into the temp grid
    if (temp_grid[0][length-1]=='\n'){                           //if a new line character at the end of a line, edit length of row to remove the character
        length=length-1;
    }
    int error = 0;                                               //an error checker used at the end of the program

    for (int j=0; j<length; j++) {                               //print the line
        printf("%c", temp_grid[0][j]);
    }

    for (int j = 0; j < length; j++) {
        if ((temp_grid[0][j] == '(') || (temp_grid[0][j] == '[') || (temp_grid[0][j] == '<')) {     //if character is an opening delimeter, enter the if statement
            if (isFull(*s)){                                                                        //if stack is full, print statement and go to next line, otherwise push
                printf(" === stack full");
                break;
            }
            push(temp_grid[0][j], s);
        }
        else if ((temp_grid[0][j] == ')') || (temp_grid[0][j] == ']') || (temp_grid[0][j] == '>')) { //if closing delimeter, enter statement
            if (isEmpty(*s)) {                                                                       //if stack is empty, print the opening delimeter missing
                if (temp_grid[0][j]==')'){
                    printf(" === missing %c", temp_grid[0][j] - 1);
                }
                else {
                    printf(" === missing %c", temp_grid[0][j] - 2);
                }
                error = -1;
                break;
            }
            char popped = pop(s);
            if (temp_grid[0][j] == ')' && popped == '(') {                  //checks if closing and opening delimeter match
                continue;
            }
            else if (temp_grid[0][j] == ']' && popped == '[') {
                continue;
            }
            else if (temp_grid[0][j] == '>' && popped == '<') {
                continue;
            }
            else {                                                         //if no match, print the missing closing delimeter for popped element
                if (popped == '('){
                    printf(" === missing %c", popped + 1);
                }
                else {
                    printf(" === missing %c", popped + 2);
                }
                while (!isEmpty(*s)){
                   pop(s);
                }
                error = -1;
                break;
            }
        }
    }

    if (!isEmpty(*s)) {
        while (!isEmpty(*s)) {
            int end  = pop(s);
            if (end == '(') {
                printf(" === missing %c", end+1);
            }
            else {
                printf(" === missing %c", end+2);
            }
        }
    }
    else if (error==-1){
        printf("");
    }
    else {
        printf(" === valid expression");
    }

    free(temp_grid[0]);
}

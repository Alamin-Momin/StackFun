//stack_arr_driver.c
// Created by Alamin Momin on 2/21/20.
//This is the driver file for the Equation Checker program

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "stack_arr.h"

int main(int argc, char *argv[]) {
    char *fName = argv[1];                  //pointer to the beginning of the file that is being read (argument element 1 in the main program)
    Stack312 stack;                         //create a new class of struct Stack312
    int lineLength = 0;                     //variable that will be used when the program has reached the end of the line

    FILE *fptr;                            //open input file and check if valid
    fptr = fopen(fName, "r");
    if (fptr == NULL) {
        printf("you screwed up!\n");
        exit(-1);
    }
    else {
        char buf[BUFSIZ];                       //create an array to store buffer
        while (fgets(buf,sizeof(buf),fptr)){
            makeStack(&stack);                  //initialize stack
            lineLength = strlen(buf);
            checker(buf, lineLength, &stack);   //call checker program
            printf(" \n");
        }
    }

    fclose(fptr);
    return 0;
}

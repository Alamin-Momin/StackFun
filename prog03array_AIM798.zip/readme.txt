The purpose of this program is to check if the delimeters of a set of "equations" in a text file match up or not,
creating a valid equation. The program reads in a line from the imported file, pushes opening delimeters to an array
implemented stack, and pops these characters when it finds a closing delimeter. It then compares the closing delimeter
and this popped chraracter. If the two match, the program continues. Otherwise, it will print an error.

Other errors the program picks up on are if all the opening delimeters do not have a corresponding closing delimeter (ie
the stack is not empty after the equation has been completely checked). Also if the stack gets full, there will be
another error.

To compile the function, type "make" into the command line. To run the program type "./check ***.***" where ***.*** is the file you want to check. There are no bugs and all test cases will work.
